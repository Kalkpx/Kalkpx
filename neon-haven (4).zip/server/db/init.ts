import {
  sequelize,
  User,
  Department,
  Folder,
  File,
  SharedFile,
  FileActivity,
} from "./connection";
import fs from "fs";
import path from "path";

export async function initializeDatabase() {
  try {
    console.log("🔄 Initializing database...");

    // Test the connection
    await sequelize.authenticate();
    console.log("✅ Database connection established successfully.");

    // Create uploads directory if it doesn't exist
    const uploadsDir = path.join(process.cwd(), "uploads");
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
      console.log("📁 Created uploads directory");
    }

    // Sync all models (create tables)
    await sequelize.sync({ force: false }); // Set to true to recreate tables
    console.log("🗃️ Database tables synchronized successfully.");

    // Check if we need to seed data
    const userCount = await User.count();
    if (userCount === 0) {
      console.log("🌱 Seeding initial data...");
      await seedDatabase();
    } else {
      console.log("📊 Database already contains data.");
    }

    console.log("✅ Database initialization complete!");
    return true;
  } catch (error) {
    console.error("❌ Database initialization failed:", error);
    throw error;
  }
}

async function seedDatabase() {
  try {
    // Create departments
    const departments = await Department.bulkCreate([
      { name: "Engineering" },
      { name: "Marketing" },
      { name: "Sales" },
      { name: "Human Resources" },
      { name: "Finance" },
    ]);

    console.log("✅ Created departments");

    // Create users individually to ensure foreign keys work
    const users = [];

    const userData = [
      {
        name: "John Doe",
        email: "john@example.com",
        password: "password123",
        role: "admin" as const,
        department_id: departments[0].id,
      },
      {
        name: "Jane Smith",
        email: "jane@example.com",
        password: "password123",
        role: "user" as const,
        department_id: departments[1].id,
      },
      {
        name: "Mike Johnson",
        email: "mike@example.com",
        password: "password123",
        role: "user" as const,
        department_id: departments[0].id,
      },
      {
        name: "Sarah Wilson",
        email: "sarah@example.com",
        password: "password123",
        role: "user" as const,
        department_id: departments[2].id,
      },
    ];

    for (const data of userData) {
      const user = await User.create(data);
      users.push(user);
    }

    console.log("✅ Created users");

    // Create some initial folders
    const folders = await Folder.bulkCreate([
      {
        name: "Documents",
        parent_id: null,
        user_id: users[0].id,
        path: "/Documents",
        full_path: "/Documents",
      },
      {
        name: "Projects",
        parent_id: null,
        user_id: users[0].id,
        path: "/Projects",
        full_path: "/Projects",
      },
      {
        name: "Marketing Materials",
        parent_id: null,
        user_id: users[1].id,
        path: "/Marketing Materials",
        full_path: "/Marketing Materials",
      },
    ]);

    console.log("✅ Created initial folders");

    // Create some sample files (metadata only)
    const files = await File.bulkCreate([
      {
        name: "Project Proposal.pdf",
        type: "application/pdf",
        size: 2450000,
        folder_id: folders[0].id,
        user_id: users[0].id,
        path: "/uploads/sample-project-proposal.pdf",
      },
      {
        name: "Budget Analysis.xlsx",
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        size: 1200000,
        folder_id: folders[1].id,
        user_id: users[0].id,
        path: "/uploads/sample-budget-analysis.xlsx",
      },
      {
        name: "Marketing Campaign.pptx",
        type: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        size: 5600000,
        folder_id: folders[2].id,
        user_id: users[1].id,
        path: "/uploads/sample-marketing-campaign.pptx",
      },
    ]);

    console.log("✅ Created sample files");

    // Create file activities
    await FileActivity.bulkCreate([
      {
        file_id: files[0].id,
        user_id: users[0].id,
        action: "uploaded",
      },
      {
        file_id: files[1].id,
        user_id: users[0].id,
        action: "uploaded",
      },
      {
        file_id: files[2].id,
        user_id: users[1].id,
        action: "uploaded",
      },
    ]);

    console.log("✅ Created file activities");

    // Create a shared file example
    await SharedFile.create({
      file_id: files[0].id,
      from_user_id: users[0].id,
      to_user_id: users[1].id,
    });

    console.log("✅ Created shared file example");
    console.log("🎉 Database seeding completed successfully!");
  } catch (error) {
    console.error("❌ Database seeding failed:", error);
    throw error;
  }
}

// Helper function to reset database (useful for development)
export async function resetDatabase() {
  try {
    console.log("🔄 Resetting database...");
    await sequelize.sync({ force: true });
    await seedDatabase();
    console.log("✅ Database reset complete!");
  } catch (error) {
    console.error("❌ Database reset failed:", error);
    throw error;
  }
}
