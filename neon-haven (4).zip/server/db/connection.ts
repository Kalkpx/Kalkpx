import { Sequelize, DataTypes, Model, Optional } from "sequelize";
import bcrypt from "bcryptjs";

// Database connection
const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: "./filevault.db",
  logging: false, // Set to console.log to see SQL queries
});

// User attributes interface
interface UserAttributes {
  id: string;
  name: string;
  email: string;
  password: string;
  department_id: string;
  role: "admin" | "user";
  created_at?: Date;
  updated_at?: Date;
}

interface UserCreationAttributes
  extends Optional<UserAttributes, "id" | "created_at" | "updated_at"> {}

// Department attributes interface
interface DepartmentAttributes {
  id: string;
  name: string;
  created_at?: Date;
  updated_at?: Date;
}

interface DepartmentCreationAttributes
  extends Optional<DepartmentAttributes, "id" | "created_at" | "updated_at"> {}

// Folder attributes interface
interface FolderAttributes {
  id: string;
  name: string;
  parent_id?: string | null;
  user_id: string;
  path: string;
  full_path: string;
  created_at?: Date;
  updated_at?: Date;
}

interface FolderCreationAttributes
  extends Optional<FolderAttributes, "id" | "created_at" | "updated_at"> {}

// File attributes interface
interface FileAttributes {
  id: string;
  folder_id?: string | null;
  user_id: string;
  name: string;
  type: string;
  size: number;
  path: string;
  created_at?: Date;
  updated_at?: Date;
}

interface FileCreationAttributes
  extends Optional<FileAttributes, "id" | "created_at" | "updated_at"> {}

// SharedFile attributes interface
interface SharedFileAttributes {
  id: string;
  file_id: string;
  from_user_id: string;
  to_user_id: string;
  shared_at?: Date;
}

interface SharedFileCreationAttributes
  extends Optional<SharedFileAttributes, "id"> {}

// FileActivity attributes interface
interface FileActivityAttributes {
  id: string;
  file_id: string;
  user_id: string;
  action: "uploaded" | "shared" | "renamed" | "deleted" | "downloaded";
  created_at?: Date;
}

interface FileActivityCreationAttributes
  extends Optional<FileActivityAttributes, "id" | "created_at"> {}

// Define Models
class Department
  extends Model<DepartmentAttributes, DepartmentCreationAttributes>
  implements DepartmentAttributes
{
  public id!: string;
  public name!: string;
  public readonly created_at!: Date;
  public readonly updated_at!: Date;
}

class User
  extends Model<UserAttributes, UserCreationAttributes>
  implements UserAttributes
{
  public id!: string;
  public name!: string;
  public email!: string;
  public password!: string;
  public department_id!: string;
  public role!: "admin" | "user";
  public readonly created_at!: Date;
  public readonly updated_at!: Date;

  // Instance methods
  public async comparePassword(candidatePassword: string): Promise<boolean> {
    return bcrypt.compare(candidatePassword, this.password);
  }
}

class Folder
  extends Model<FolderAttributes, FolderCreationAttributes>
  implements FolderAttributes
{
  public id!: string;
  public name!: string;
  public parent_id!: string | null;
  public user_id!: string;
  public path!: string;
  public full_path!: string;
  public readonly created_at!: Date;
  public readonly updated_at!: Date;
}

class File
  extends Model<FileAttributes, FileCreationAttributes>
  implements FileAttributes
{
  public id!: string;
  public folder_id!: string | null;
  public user_id!: string;
  public name!: string;
  public type!: string;
  public size!: number;
  public path!: string;
  public readonly created_at!: Date;
  public readonly updated_at!: Date;
}

class SharedFile
  extends Model<SharedFileAttributes, SharedFileCreationAttributes>
  implements SharedFileAttributes
{
  public id!: string;
  public file_id!: string;
  public from_user_id!: string;
  public to_user_id!: string;
  public shared_at!: Date;
}

class FileActivity
  extends Model<FileActivityAttributes, FileActivityCreationAttributes>
  implements FileActivityAttributes
{
  public id!: string;
  public file_id!: string;
  public user_id!: string;
  public action!: "uploaded" | "shared" | "renamed" | "deleted" | "downloaded";
  public readonly created_at!: Date;
}

// Initialize models
Department.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    sequelize,
    modelName: "Department",
    tableName: "departments",
    underscored: true,
  },
);

User.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true,
      },
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    department_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: Department,
        key: "id",
      },
    },
    role: {
      type: DataTypes.ENUM("admin", "user"),
      defaultValue: "user",
    },
  },
  {
    sequelize,
    modelName: "User",
    tableName: "users",
    underscored: true,
    hooks: {
      beforeCreate: async (user: User) => {
        if (user.password) {
          const salt = await bcrypt.genSalt(10);
          user.password = await bcrypt.hash(user.password, salt);
        }
      },
      beforeUpdate: async (user: User) => {
        if (user.changed("password")) {
          const salt = await bcrypt.genSalt(10);
          user.password = await bcrypt.hash(user.password, salt);
        }
      },
    },
  },
);

Folder.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    parent_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: "folders",
        key: "id",
      },
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: User,
        key: "id",
      },
    },
    path: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    full_path: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    sequelize,
    modelName: "Folder",
    tableName: "folders",
    underscored: true,
  },
);

File.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    folder_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: Folder,
        key: "id",
      },
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: User,
        key: "id",
      },
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    size: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    path: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    sequelize,
    modelName: "File",
    tableName: "files",
    underscored: true,
  },
);

SharedFile.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    file_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: File,
        key: "id",
      },
    },
    from_user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: User,
        key: "id",
      },
    },
    to_user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: User,
        key: "id",
      },
    },
    shared_at: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    sequelize,
    modelName: "SharedFile",
    tableName: "shared_files",
    underscored: true,
    timestamps: false,
  },
);

FileActivity.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    file_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: File,
        key: "id",
      },
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: User,
        key: "id",
      },
    },
    action: {
      type: DataTypes.ENUM(
        "uploaded",
        "shared",
        "renamed",
        "deleted",
        "downloaded",
      ),
      allowNull: false,
    },
  },
  {
    sequelize,
    modelName: "FileActivity",
    tableName: "file_activities",
    underscored: true,
    updatedAt: false,
  },
);

// Define associations
User.belongsTo(Department, { foreignKey: "department_id", as: "department" });
Department.hasMany(User, { foreignKey: "department_id", as: "users" });

Folder.belongsTo(User, { foreignKey: "user_id", as: "user" });
Folder.belongsTo(Folder, { foreignKey: "parent_id", as: "parent" });
Folder.hasMany(Folder, { foreignKey: "parent_id", as: "children" });

File.belongsTo(User, { foreignKey: "user_id", as: "user" });
File.belongsTo(Folder, { foreignKey: "folder_id", as: "folder" });

SharedFile.belongsTo(File, { foreignKey: "file_id", as: "file" });
SharedFile.belongsTo(User, { foreignKey: "from_user_id", as: "fromUser" });
SharedFile.belongsTo(User, { foreignKey: "to_user_id", as: "toUser" });

FileActivity.belongsTo(File, { foreignKey: "file_id", as: "file" });
FileActivity.belongsTo(User, { foreignKey: "user_id", as: "user" });

export { sequelize, User, Department, Folder, File, SharedFile, FileActivity };
