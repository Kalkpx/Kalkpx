import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { User } from "./db/connection";

// JWT secret (in production, use environment variable)
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-this";

interface TokenPayload {
  userId: string;
  email: string;
  role: string;
}

// JWT functions using proper jsonwebtoken library
export const jwtUtils = {
  sign: (payload: TokenPayload): string => {
    return jwt.sign(payload, JWT_SECRET, { expiresIn: "7d" });
  },
  verify: (token: string): TokenPayload | null => {
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      console.log("JWT decoded:", decoded);
      return {
        userId: decoded.userId,
        email: decoded.email,
        role: decoded.role,
      };
    } catch (error) {
      console.error("JWT verification failed:", error);
      return null;
    }
  },
};

// Mock reCAPTCHA verification
export const verifyRecaptcha = async (token: string): Promise<boolean> => {
  // In production, verify with Google reCAPTCHA API
  return token === "dummy_recaptcha_token" || token.length > 0;
};

// Authentication middleware
export const authenticateToken = async (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  try {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];

    console.log("Auth header:", authHeader);
    console.log("Extracted token:", token ? "exists" : "missing");

    if (!token) {
      return res.status(401).json({ error: "Access token required" });
    }

    const payload = jwtUtils.verify(token);
    if (!payload) {
      return res.status(403).json({ error: "Invalid or expired token" });
    }

    console.log("Token payload:", payload);

    // For demo purposes, create a mock user object
    if (payload.userId === "demo-user-123") {
      const mockUser = {
        id: payload.userId,
        name: "Demo User",
        email: payload.email,
        role: payload.role,
        department_id: "demo-dept",
        created_at: new Date(),
        updated_at: new Date(),
      };

      console.log("Demo user authenticated:", mockUser.email);

      // Add user to request object
      (req as any).user = mockUser;
    } else {
      const user = await User.findByPk(payload.userId, {
        include: [{ association: "department" }],
      });
      if (!user) {
        console.log("User not found for ID:", payload.userId);
        return res.status(403).json({ error: "User not found" });
      }

      console.log("Database user authenticated:", user.email);
      (req as any).user = user;
    }
    next();
  } catch (error) {
    console.error("Authentication error:", error);
    return res.status(403).json({ error: "Authentication failed" });
  }
};

// Get current user from request
export const getCurrentUser = (req: Request): User | null => {
  return (req as any).user || null;
};

// Check if user has admin role
export const requireAdmin = (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  const user = getCurrentUser(req);
  if (!user || user.role !== "admin") {
    return res.status(403).json({ error: "Admin access required" });
  }
  next();
};
