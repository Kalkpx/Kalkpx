import { Request, Response } from "express";
import { User, File, Folder, SharedFile, FileActivity } from "../db/connection";
import { getCurrentUser } from "../auth";

export const handleSearchUsers = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { q } = req.query;
    const searchTerm = (q as string)?.toLowerCase().trim();

    if (!searchTerm || searchTerm.length < 2) {
      return res.status(400).json({ error: "Search term too short" });
    }

    const users = await User.findAll({
      where: {
        // Exclude current user from search
        // Add search functionality here if needed
      },
      include: [{ association: "department" }],
      limit: 10,
    });

    const userResults = users
      .filter((u) => u.id !== user.id)
      .filter((u) => u.name.toLowerCase().includes(searchTerm))
      .map((u) => ({
        id: u.id,
        name: u.name,
        email: u.email,
        department: (u as any).department?.name || "Unknown",
        role: u.role,
      }));

    res.json({ users: userResults });
  } catch (error) {
    console.error("Search users error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleGetDashboardStats = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const totalFiles = await File.count({ where: { user_id: user.id } });
    const totalFolders = await Folder.count({ where: { user_id: user.id } });

    const files = await File.findAll({ where: { user_id: user.id } });
    const totalStorage = files.reduce((acc, file) => acc + file.size, 0);

    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const recentFiles = await File.count({
      where: {
        user_id: user.id,
        created_at: { [require("sequelize").Op.gte]: sevenDaysAgo },
      },
    });

    const sharedByMeCount = await SharedFile.count({
      where: { from_user_id: user.id },
    });
    const sharedWithMeCount = await SharedFile.count({
      where: { to_user_id: user.id },
    });

    const recentActivities = await FileActivity.findAll({
      where: { user_id: user.id },
      include: [{ association: "file" }],
      order: [["created_at", "DESC"]],
      limit: 10,
    });

    const stats = {
      totalFiles,
      totalFolders,
      totalStorage,
      recentFiles,
      sharedByMeCount,
      sharedWithMeCount,
      recentActivities: recentActivities.map((activity) => ({
        id: activity.id,
        action: activity.action,
        fileName: (activity as any).file?.name || "Unknown",
        created_at: activity.created_at,
      })),
      storageLimit: 10 * 1024 * 1024 * 1024, // 10GB
    };

    res.json({ stats });
  } catch (error) {
    console.error("Get dashboard stats error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleGetRecentFiles = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { limit = 10 } = req.query;

    const files = await File.findAll({
      where: { user_id: user.id },
      include: [{ association: "folder" }],
      order: [["created_at", "DESC"]],
      limit: parseInt(limit as string),
    });

    const filesWithDetails = await Promise.all(
      files.map(async (file) => {
        const sharedCount = await SharedFile.count({
          where: { file_id: file.id },
        });

        return {
          id: file.id,
          name: file.name,
          type: "file" as const,
          size: file.size,
          modifiedAt: file.updated_at,
          sharedCount,
          folderName: (file as any).folder?.name || null,
        };
      }),
    );

    res.json({ files: filesWithDetails });
  } catch (error) {
    console.error("Get recent files error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
