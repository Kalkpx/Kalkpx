import { Request, Response } from "express";
import { z } from "zod";
import { Folder, File } from "../db/connection";
import { getCurrentUser } from "../auth";
import {
  getDemoFolders,
  addDemoFolder,
  updateDemoFolder,
  deleteDemoFolder,
} from "../utils/demoData";

// Validation schemas
const createFolderSchema = z.object({
  name: z.string().min(1),
  parent_id: z.string().nullable().optional(),
});

const updateFolderSchema = z.object({
  name: z.string().min(1).optional(),
  parent_id: z.string().nullable().optional(),
  path: z.string().optional(),
  full_path: z.string().optional(),
});

export const handleGetFolders = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { parent_id } = req.query;

    // For demo user, return demo folders
    if (user.id === "demo-user-123") {
      const demoFolders = getDemoFolders();
      const filteredFolders = demoFolders.filter((folder) => {
        if (parent_id === "null" || parent_id === undefined) {
          return !folder.parent_id;
        } else {
          return folder.parent_id === parent_id;
        }
      });

      const foldersWithCounts = filteredFolders.map((folder) => ({
        id: folder.id,
        name: folder.name,
        type: "folder" as const,
        modifiedAt: folder.modifiedAt,
        fileCount: 0, // Simplified for demo
        subfolderCount: 0, // Simplified for demo
      }));

      res.json({ folders: foldersWithCounts });
      return;
    }

    let whereClause: any = { user_id: user.id };
    if (parent_id === "null" || parent_id === undefined) {
      whereClause.parent_id = null;
    } else {
      whereClause.parent_id = parent_id;
    }

    const folders = await Folder.findAll({
      where: whereClause,
      order: [["name", "ASC"]],
    });

    const foldersWithCounts = await Promise.all(
      folders.map(async (folder) => {
        const fileCount = await File.count({
          where: { folder_id: folder.id },
        });
        const subfolderCount = await Folder.count({
          where: { parent_id: folder.id, user_id: user.id },
        });

        return {
          id: folder.id,
          name: folder.name,
          type: "folder" as const,
          modifiedAt: folder.updated_at,
          fileCount,
          subfolderCount,
        };
      }),
    );

    res.json({ folders: foldersWithCounts });
  } catch (error) {
    console.error("Get folders error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleCreateFolder = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { name, parent_id } = createFolderSchema.parse(req.body);

    // For demo user, use in-memory storage simulation
    if (user.id === "demo-user-123") {
      // Create a mock folder response for demo user
      const mockFolder = {
        id: `folder-${Date.now()}`,
        name,
        type: "folder" as const,
        modifiedAt: new Date(),
        parent_id: parent_id || null,
      };

      // Store in persistent demo folders
      addDemoFolder(mockFolder);

      console.log("Created demo folder:", mockFolder);

      res.status(201).json({
        folder: mockFolder,
        message: "Folder created successfully",
      });
      return;
    }

    // If parent_id is provided, check if user owns the parent folder
    let parentFolder = null;
    if (parent_id) {
      parentFolder = await Folder.findOne({
        where: { id: parent_id, user_id: user.id },
      });
      if (!parentFolder) {
        return res
          .status(403)
          .json({ error: "Access denied to parent folder" });
      }
    }

    // Build paths
    const parentPath = parentFolder ? parentFolder.full_path : "";
    const fullPath = parentPath ? `${parentPath}/${name}` : `/${name}`;

    // Check if folder with same name exists in the same parent
    const existingFolder = await Folder.findOne({
      where: {
        parent_id: parent_id || null,
        name,
        user_id: user.id,
      },
    });

    if (existingFolder) {
      return res.status(400).json({
        error: "A folder with this name already exists in this location",
      });
    }

    // Create folder
    const newFolder = await Folder.create({
      name,
      parent_id: parent_id || null,
      user_id: user.id,
      path: fullPath,
      full_path: fullPath,
    });

    res.status(201).json({
      folder: {
        id: newFolder.id,
        name: newFolder.name,
        type: "folder" as const,
        modifiedAt: newFolder.created_at,
      },
      message: "Folder created successfully",
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid input data" });
    }
    console.error("Create folder error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleDeleteFolder = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { id } = req.params;

    // For demo user, delete from persistent demo data
    if (user.id === "demo-user-123") {
      console.log(`Attempting to delete folder with ID: ${id}`);
      const demoFolders = getDemoFolders();
      console.log(
        `Current demo folders:`,
        demoFolders.map((f) => ({ id: f.id, name: f.name })),
      );

      const deleted = deleteDemoFolder(id);
      console.log(`Delete result: ${deleted}`);

      if (!deleted) {
        return res.status(404).json({ error: "Folder not found" });
      }

      res.json({ message: "Folder deleted successfully" });
      return;
    }

    // For real users, delete from database
    const folder = await Folder.findOne({
      where: { id, user_id: user.id },
    });

    if (!folder) {
      return res.status(404).json({ error: "Folder not found" });
    }

    // Check if folder has contents
    const subfolders = await Folder.count({
      where: { parent_id: id, user_id: user.id },
    });
    const files = await File.count({
      where: { folder_id: id },
    });

    if (subfolders > 0 || files > 0) {
      return res.status(400).json({
        error:
          "Cannot delete folder with contents. Please delete all files and subfolders first.",
      });
    }

    await folder.destroy();

    res.json({ message: "Folder deleted successfully" });
  } catch (error) {
    console.error("Delete folder error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

// Placeholder handlers
export const handleGetFolder = async (req: Request, res: Response) => {
  res.status(501).json({ error: "Not implemented yet" });
};

export const handleUpdateFolder = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { id } = req.params;
    const { name } = req.body;

    if (!name || name.trim() === "") {
      return res.status(400).json({ error: "Folder name is required" });
    }

    // For demo user, update in persistent demo data
    if (user.id === "demo-user-123") {
      const updated = updateDemoFolder(id, {
        name: name.trim(),
        modifiedAt: new Date(),
      });

      if (!updated) {
        return res.status(404).json({ error: "Folder not found" });
      }

      const demoFolders = getDemoFolders();
      const updatedFolder = demoFolders.find((folder) => folder.id === id);

      res.json({
        message: "Folder renamed successfully",
        folder: updatedFolder,
      });
      return;
    }

    // For real users, update in database
    const folder = await Folder.findOne({
      where: { id, user_id: user.id },
    });

    if (!folder) {
      return res.status(404).json({ error: "Folder not found" });
    }

    // Check if folder with same name exists in the same parent
    const existingFolder = await Folder.findOne({
      where: {
        parent_id: folder.parent_id,
        name: name.trim(),
        user_id: user.id,
        id: { [require("sequelize").Op.ne]: id }, // Exclude current folder
      },
    });

    if (existingFolder) {
      return res.status(400).json({
        error: "A folder with this name already exists in this location",
      });
    }

    // Update folder name and paths
    const oldPath = folder.full_path;
    const parentPath = folder.parent_id
      ? (await Folder.findByPk(folder.parent_id))?.full_path || ""
      : "";
    const newPath = parentPath
      ? `${parentPath}/${name.trim()}`
      : `/${name.trim()}`;

    await folder.update({
      name: name.trim(),
      path: newPath,
      full_path: newPath,
    });

    // TODO: Update paths of all subfolders and files recursively
    // This is a complex operation that would require updating all nested items

    res.json({
      message: "Folder renamed successfully",
      folder: {
        id: folder.id,
        name: folder.name,
        type: "folder" as const,
        modifiedAt: folder.updated_at,
      },
    });
  } catch (error) {
    console.error("Update folder error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleGetFolderTree = async (req: Request, res: Response) => {
  res.json({ tree: [] });
};
