import { Request, Response } from "express";
import { z } from "zod";
import multer from "multer";
import { File, Folder, SharedFile, FileActivity, User } from "../db/connection";
import { getCurrentUser } from "../auth";
import {
  getDemoFiles,
  addDemoFile,
  updateDemoFile,
  deleteDemoFile,
} from "../utils/demoData";

// Validation schemas
const createFileSchema = z.object({
  name: z.string().min(1),
  type: z.string().min(1),
  size: z.number().positive(),
  folder_id: z.string().nullable().optional(),
});

export const handleGetFiles = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { folder_id } = req.query;

    // For demo user, return demo files
    if (user.id === "demo-user-123") {
      const demoFiles = getDemoFiles();
      const filteredFiles = demoFiles.filter((file) => {
        if (folder_id && folder_id !== "null") {
          return file.folder_id === folder_id;
        } else {
          return !file.folder_id;
        }
      });

      res.json({ files: filteredFiles });
      return;
    }

    let whereClause: any = { user_id: user.id };
    if (folder_id && folder_id !== "null") {
      whereClause.folder_id = folder_id;
    } else {
      whereClause.folder_id = null;
    }

    const files = await File.findAll({
      where: whereClause,
      order: [["created_at", "DESC"]],
    });

    const filesWithSharedCount = await Promise.all(
      files.map(async (file) => {
        const sharedCount = await SharedFile.count({
          where: { file_id: file.id },
        });

        return {
          id: file.id,
          name: file.name,
          type: "file" as const,
          size: file.size,
          modifiedAt: file.updated_at,
          sharedWith: sharedCount,
        };
      }),
    );

    res.json({ files: filesWithSharedCount });
  } catch (error) {
    console.error("Get files error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleFileUpload = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const files = req.files as any[];
    if (!files || files.length === 0) {
      return res.status(400).json({ error: "No files uploaded" });
    }

    const { folder_id } = req.body;

    // For demo user, simulate file uploads
    if (user.id === "demo-user-123") {
      const uploadedFiles = files.map((file) => {
        const fileData = {
          id: `file-${Date.now()}-${Math.random()}`,
          name: file.originalname,
          type: "file" as const,
          size: file.size,
          modifiedAt: new Date(),
          sharedWith: 0,
          folder_id: folder_id && folder_id !== "null" ? folder_id : null,
        };

        // Store in persistent demo files
        addDemoFile(fileData);

        return fileData;
      });

      res.status(201).json({
        files: uploadedFiles,
        message: `Successfully uploaded ${files.length} file(s)`,
      });
      return;
    }

    const uploadedFiles = [];

    for (const file of files) {
      const newFile = await File.create({
        name: file.originalname,
        type: file.mimetype,
        size: file.size,
        folder_id: folder_id && folder_id !== "null" ? folder_id : null,
        user_id: user.id,
        path: file.path,
      });

      await FileActivity.create({
        file_id: newFile.id,
        user_id: user.id,
        action: "uploaded",
      });

      uploadedFiles.push({
        id: newFile.id,
        name: newFile.name,
        type: "file" as const,
        size: newFile.size,
        modifiedAt: newFile.created_at,
        sharedWith: 0,
      });
    }

    res.status(201).json({
      files: uploadedFiles,
      message: `Successfully uploaded ${files.length} file(s)`,
    });
  } catch (error) {
    console.error("File upload error:", error);
    res.status(500).json({ error: "File upload failed" });
  }
};

export const handleCreateFile = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { name, type, size, folder_id } = createFileSchema.parse(req.body);

    const newFile = await File.create({
      name,
      type,
      size,
      folder_id: folder_id || null,
      user_id: user.id,
      path: `/uploads/placeholder-${Date.now()}-${name}`,
    });

    await FileActivity.create({
      file_id: newFile.id,
      user_id: user.id,
      action: "uploaded",
    });

    res.status(201).json({
      file: {
        id: newFile.id,
        name: newFile.name,
        type: "file" as const,
        size: newFile.size,
        modifiedAt: newFile.created_at,
        sharedWith: 0,
      },
      message: "File uploaded successfully",
    });
  } catch (error) {
    console.error("Create file error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleDeleteFile = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { id } = req.params;

    // For demo user, delete from persistent demo data
    if (user.id === "demo-user-123") {
      console.log(`Attempting to delete file with ID: ${id}`);
      const demoFiles = getDemoFiles();
      console.log(
        `Current demo files:`,
        demoFiles.map((f) => ({ id: f.id, name: f.name })),
      );

      const deleted = deleteDemoFile(id);
      console.log(`Delete result: ${deleted}`);

      if (!deleted) {
        return res.status(404).json({ error: "File not found" });
      }

      res.json({ message: "File deleted successfully" });
      return;
    }

    // For real users, delete from database
    const file = await File.findOne({
      where: { id, user_id: user.id },
    });

    if (!file) {
      return res.status(404).json({ error: "File not found" });
    }

    await file.destroy();

    await FileActivity.create({
      file_id: file.id,
      user_id: user.id,
      action: "deleted",
    });

    res.json({ message: "File deleted successfully" });
  } catch (error) {
    console.error("Delete file error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

// Placeholder handlers for missing functionality
export const handleGetFile = async (req: Request, res: Response) => {
  res.status(501).json({ error: "Not implemented yet" });
};

export const handleUpdateFile = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { id } = req.params;
    const { name } = req.body;

    if (!name || name.trim() === "") {
      return res.status(400).json({ error: "File name is required" });
    }

    // For demo user, update in persistent demo data
    if (user.id === "demo-user-123") {
      const updated = updateDemoFile(id, {
        name: name.trim(),
        modifiedAt: new Date(),
      });

      if (!updated) {
        return res.status(404).json({ error: "File not found" });
      }

      const demoFiles = getDemoFiles();
      const updatedFile = demoFiles.find((file) => file.id === id);

      res.json({
        message: "File renamed successfully",
        file: updatedFile,
      });
      return;
    }

    // For real users, update in database
    const file = await File.findOne({
      where: { id, user_id: user.id },
    });

    if (!file) {
      return res.status(404).json({ error: "File not found" });
    }

    // Update the file name
    await file.update({ name: name.trim() });

    // Log rename activity
    await FileActivity.create({
      file_id: file.id,
      user_id: user.id,
      action: "renamed",
    });

    res.json({
      message: "File renamed successfully",
      file: {
        id: file.id,
        name: file.name,
        type: "file" as const,
        size: file.size,
        modifiedAt: file.updated_at,
      },
    });
  } catch (error) {
    console.error("Update file error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleDownloadFile = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { id } = req.params;

    // For demo user, simulate file download
    if (user.id === "demo-user-123") {
      // Find the demo file
      const demoFiles = getDemoFiles();
      const demoFile = demoFiles.find((file) => file.id === id);
      if (!demoFile) {
        return res.status(404).json({ error: "File not found" });
      }

      // For demo, just return a success message
      res.json({
        message: `Download initiated for "${demoFile.name}"`,
        downloadUrl: `/uploads/demo-${demoFile.name}`,
      });
      return;
    }

    // For real users, find the file in database
    const file = await File.findOne({
      where: { id, user_id: user.id },
    });

    if (!file) {
      return res.status(404).json({ error: "File not found" });
    }

    // Check if file exists on disk
    const fs = require("fs");
    const path = require("path");

    if (!fs.existsSync(file.path)) {
      return res.status(404).json({ error: "File not found on disk" });
    }

    // Set headers for file download
    res.setHeader("Content-Disposition", `attachment; filename="${file.name}"`);
    res.setHeader("Content-Type", file.type || "application/octet-stream");

    // Stream the file
    const fileStream = fs.createReadStream(file.path);
    fileStream.pipe(res);

    // Log download activity
    await FileActivity.create({
      file_id: file.id,
      user_id: user.id,
      action: "downloaded",
    });
  } catch (error) {
    console.error("Download file error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleShareFile = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { id } = req.params;
    const { to_user_id } = req.body;

    if (!to_user_id) {
      return res.status(400).json({ error: "Target user ID is required" });
    }

    // For demo user, simulate sharing
    if (user.id === "demo-user-123") {
      const demoFiles = getDemoFiles();
      const demoFile = demoFiles.find((file) => file.id === id);
      if (!demoFile) {
        return res.status(404).json({ error: "File not found" });
      }

      res.json({
        message: `File "${demoFile.name}" shared successfully`,
        sharedWith: to_user_id,
      });
      return;
    }

    // For real users, check if file exists and user owns it
    const file = await File.findOne({
      where: { id, user_id: user.id },
    });

    if (!file) {
      return res.status(404).json({ error: "File not found" });
    }

    // Check if target user exists
    const targetUser = await User.findByPk(to_user_id);
    if (!targetUser) {
      return res.status(404).json({ error: "Target user not found" });
    }

    // Check if already shared
    const existingShare = await SharedFile.findOne({
      where: { file_id: id, to_user_id },
    });

    if (existingShare) {
      return res
        .status(400)
        .json({ error: "File already shared with this user" });
    }

    // Create share record
    await SharedFile.create({
      file_id: id,
      from_user_id: user.id,
      to_user_id,
    });

    // Log sharing activity
    await FileActivity.create({
      file_id: file.id,
      user_id: user.id,
      action: "shared",
    });

    res.json({ message: "File shared successfully" });
  } catch (error) {
    console.error("Share file error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleGetSharedFiles = async (req: Request, res: Response) => {
  res.json({ files: [] });
};
