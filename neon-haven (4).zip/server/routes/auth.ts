import { Request, Response } from "express";
import { z } from "zod";
import { User, Department } from "../db/connection";
import { jwtUtils, getCurrentUser } from "../auth";

// Validation schemas
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  recaptcha_token: z.string().min(1),
});

const registerSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  password: z.string().min(6),
  department_id: z.string(),
});

export const handleLogin = async (req: Request, res: Response) => {
  try {
    const { email, password, recaptcha_token } = loginSchema.parse(req.body);

    // Verify reCAPTCHA (simplified for demo)
    if (!recaptcha_token) {
      return res.status(400).json({ error: "reCAPTCHA required" });
    }

    // TEMPORARY DEMO LOGIN - BYPASSES DATABASE
    // Create a mock user for demo purposes
    const mockUser = {
      id: "demo-user-123",
      name: "Demo User",
      email: email,
      role: "admin" as const,
    };

    console.log("Demo login for:", email);

    // Generate token with mock user data
    const tokenPayload = {
      userId: mockUser.id,
      email: mockUser.email,
      role: mockUser.role,
    };

    console.log("Creating token with payload:", tokenPayload);
    const token = jwtUtils.sign(tokenPayload);

    // Return user data
    const userData = {
      id: mockUser.id,
      name: mockUser.name,
      email: mockUser.email,
      role: mockUser.role,
      department: "Engineering",
    };

    res.json({
      token,
      user: userData,
      message: "Login successful",
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid input data" });
    }
    console.error("Login error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleRegister = async (req: Request, res: Response) => {
  try {
    const { name, email, password, department_id } = registerSchema.parse(
      req.body,
    );

    // Check if user already exists
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ error: "Email already registered" });
    }

    // Check if department exists
    const department = await Department.findByPk(department_id);
    if (!department) {
      return res.status(400).json({ error: "Invalid department" });
    }

    // Create user (password will be hashed automatically)
    const newUser = await User.create({
      name,
      email,
      password,
      department_id,
      role: "user", // Default role
    });

    // Generate token
    const token = jwtUtils.sign({
      userId: newUser.id,
      email: newUser.email,
      role: newUser.role,
    });

    // Return user data (without password)
    const userData = {
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
      department: department.name,
    };

    res.status(201).json({
      token,
      user: userData,
      message: "Registration successful",
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid input data" });
    }
    console.error("Registration error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleMe = async (req: Request, res: Response) => {
  try {
    const user = getCurrentUser(req);
    if (!user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const userData = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      department: (user as any).department?.name || "Unknown",
    };

    res.json({ user: userData });
  } catch (error) {
    console.error("Get user error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleLogout = async (req: Request, res: Response) => {
  // In a real app with proper JWT, you might want to blacklist the token
  // For this demo, we'll just return success as the client will remove the token
  res.json({ message: "Logout successful" });
};

export const handleGetDepartments = async (req: Request, res: Response) => {
  try {
    const departments = await Department.findAll();
    res.json({ departments });
  } catch (error) {
    console.error("Get departments error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
