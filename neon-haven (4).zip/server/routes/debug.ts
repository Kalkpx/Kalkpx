import { Request, Response } from "express";
import {
  User,
  Department,
  Folder,
  File,
  SharedFile,
  FileActivity,
} from "../db/connection";

export const handleViewUsers = async (req: Request, res: Response) => {
  try {
    const users = await User.findAll({
      include: [{ association: "department" }],
    });

    const userData = users.map((user) => ({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      department: (user as any).department?.name || "Unknown",
      created_at: user.created_at,
    }));

    res.json({ users: userData });
  } catch (error) {
    console.error("Error viewing users:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleViewDepartments = async (req: Request, res: Response) => {
  try {
    const departments = await Department.findAll();
    res.json({ departments });
  } catch (error) {
    console.error("Error viewing departments:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleViewAllTables = async (req: Request, res: Response) => {
  try {
    const [users, departments, folders, files, sharedFiles, activities] =
      await Promise.all([
        User.findAll({ include: [{ association: "department" }] }),
        Department.findAll(),
        Folder.findAll(),
        File.findAll(),
        SharedFile.findAll(),
        FileActivity.findAll(),
      ]);

    res.json({
      users: users.map((user) => ({
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        department: (user as any).department?.name || "Unknown",
        created_at: user.created_at,
      })),
      departments,
      folders,
      files,
      sharedFiles,
      activities,
    });
  } catch (error) {
    console.error("Error viewing tables:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
