// Mock database - In production, replace with actual database (MySQL, PostgreSQL, etc.)

export interface User {
  id: string;
  name: string;
  email: string;
  password: string; // In production, this should be hashed with Argon2
  department_id: string;
  role: "admin" | "user";
  created_at: Date;
  updated_at: Date;
}

export interface Department {
  id: string;
  name: string;
  created_at: Date;
  updated_at: Date;
}

export interface Folder {
  id: string;
  name: string;
  parent_id: string | null;
  user_id: string;
  path: string;
  full_path: string;
  created_at: Date;
  updated_at: Date;
}

export interface FileRecord {
  id: string;
  folder_id: string | null;
  user_id: string;
  name: string;
  type: string;
  size: number;
  path: string;
  created_at: Date;
  updated_at: Date;
}

export interface SharedFile {
  id: string;
  file_id: string;
  from_user_id: string;
  to_user_id: string;
  shared_at: Date;
}

export interface FileActivity {
  id: string;
  file_id: string;
  user_id: string;
  action: "uploaded" | "shared" | "renamed" | "deleted" | "downloaded";
  created_at: Date;
}

// Mock data
const departments: Department[] = [
  {
    id: "dept-1",
    name: "Engineering",
    created_at: new Date("2024-01-01"),
    updated_at: new Date("2024-01-01"),
  },
  {
    id: "dept-2",
    name: "Marketing",
    created_at: new Date("2024-01-01"),
    updated_at: new Date("2024-01-01"),
  },
  {
    id: "dept-3",
    name: "Sales",
    created_at: new Date("2024-01-01"),
    updated_at: new Date("2024-01-01"),
  },
];

const users: User[] = [
  {
    id: "user-1",
    name: "John Doe",
    email: "john@example.com",
    password: "password123", // In production: hash with Argon2
    department_id: "dept-1",
    role: "admin",
    created_at: new Date("2024-01-01"),
    updated_at: new Date("2024-01-01"),
  },
  {
    id: "user-2",
    name: "Jane Smith",
    email: "jane@example.com",
    password: "password123",
    department_id: "dept-2",
    role: "user",
    created_at: new Date("2024-01-01"),
    updated_at: new Date("2024-01-01"),
  },
  {
    id: "user-3",
    name: "Mike Johnson",
    email: "mike@example.com",
    password: "password123",
    department_id: "dept-1",
    role: "user",
    created_at: new Date("2024-01-01"),
    updated_at: new Date("2024-01-01"),
  },
];

const folders: Folder[] = [
  {
    id: "folder-1",
    name: "Documents",
    parent_id: null,
    user_id: "user-1",
    path: "/Documents",
    full_path: "/Documents",
    created_at: new Date("2024-01-05"),
    updated_at: new Date("2024-01-05"),
  },
  {
    id: "folder-2",
    name: "Projects",
    parent_id: "folder-1",
    user_id: "user-1",
    path: "/Documents/Projects",
    full_path: "/Documents/Projects",
    created_at: new Date("2024-01-06"),
    updated_at: new Date("2024-01-06"),
  },
  {
    id: "folder-3",
    name: "Images",
    parent_id: null,
    user_id: "user-1",
    path: "/Images",
    full_path: "/Images",
    created_at: new Date("2024-01-07"),
    updated_at: new Date("2024-01-07"),
  },
];

const files: FileRecord[] = [
  {
    id: "file-1",
    folder_id: "folder-1",
    user_id: "user-1",
    name: "Project Proposal.pdf",
    type: "application/pdf",
    size: 2450000,
    path: "/uploads/project-proposal.pdf",
    created_at: new Date("2024-01-15"),
    updated_at: new Date("2024-01-15"),
  },
  {
    id: "file-2",
    folder_id: "folder-2",
    user_id: "user-1",
    name: "Budget Analysis.xlsx",
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    size: 1200000,
    path: "/uploads/budget-analysis.xlsx",
    created_at: new Date("2024-01-14"),
    updated_at: new Date("2024-01-14"),
  },
  {
    id: "file-3",
    folder_id: null,
    user_id: "user-1",
    name: "Presentation.pptx",
    type: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    size: 5600000,
    path: "/uploads/presentation.pptx",
    created_at: new Date("2024-01-12"),
    updated_at: new Date("2024-01-12"),
  },
  {
    id: "file-4",
    folder_id: "folder-1",
    user_id: "user-2",
    name: "Technical Specs.docx",
    type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    size: 890000,
    path: "/uploads/technical-specs.docx",
    created_at: new Date("2024-01-11"),
    updated_at: new Date("2024-01-11"),
  },
  {
    id: "file-5",
    folder_id: null,
    user_id: "user-3",
    name: "Floor Plan.dwg",
    type: "image/vnd.dwg",
    size: 3200000,
    path: "/uploads/floor-plan.dwg",
    created_at: new Date("2024-01-10"),
    updated_at: new Date("2024-01-10"),
  },
];

const sharedFiles: SharedFile[] = [
  {
    id: "share-1",
    file_id: "file-2",
    from_user_id: "user-1",
    to_user_id: "user-2",
    shared_at: new Date("2024-01-14"),
  },
  {
    id: "share-2",
    file_id: "file-4",
    from_user_id: "user-2",
    to_user_id: "user-1",
    shared_at: new Date("2024-01-11"),
  },
];

const fileActivities: FileActivity[] = [
  {
    id: "activity-1",
    file_id: "file-1",
    user_id: "user-1",
    action: "uploaded",
    created_at: new Date("2024-01-15"),
  },
  {
    id: "activity-2",
    file_id: "file-2",
    user_id: "user-1",
    action: "shared",
    created_at: new Date("2024-01-14"),
  },
];

// Database operations
export const db = {
  users: {
    findByEmail: (email: string) => users.find((u) => u.email === email),
    findById: (id: string) => users.find((u) => u.id === id),
    findAll: () => users,
    create: (userData: Omit<User, "id" | "created_at" | "updated_at">) => {
      const newUser: User = {
        ...userData,
        id: `user-${Date.now()}`,
        created_at: new Date(),
        updated_at: new Date(),
      };
      users.push(newUser);
      return newUser;
    },
  },

  departments: {
    findById: (id: string) => departments.find((d) => d.id === id),
    findAll: () => departments,
  },

  folders: {
    findByUserId: (userId: string) =>
      folders.filter((f) => f.user_id === userId),
    findById: (id: string) => folders.find((f) => f.id === id),
    findByParentId: (parentId: string | null) =>
      folders.filter((f) => f.parent_id === parentId),
    create: (folderData: Omit<Folder, "id" | "created_at" | "updated_at">) => {
      const newFolder: Folder = {
        ...folderData,
        id: `folder-${Date.now()}`,
        created_at: new Date(),
        updated_at: new Date(),
      };
      folders.push(newFolder);
      return newFolder;
    },
    update: (id: string, updates: Partial<Folder>) => {
      const index = folders.findIndex((f) => f.id === id);
      if (index !== -1) {
        folders[index] = {
          ...folders[index],
          ...updates,
          updated_at: new Date(),
        };
        return folders[index];
      }
      return null;
    },
    delete: (id: string) => {
      const index = folders.findIndex((f) => f.id === id);
      if (index !== -1) {
        return folders.splice(index, 1)[0];
      }
      return null;
    },
  },

  files: {
    findByUserId: (userId: string) => files.filter((f) => f.user_id === userId),
    findById: (id: string) => files.find((f) => f.id === id),
    findByFolderId: (folderId: string | null) =>
      files.filter((f) => f.folder_id === folderId),
    create: (
      fileData: Omit<FileRecord, "id" | "created_at" | "updated_at">,
    ) => {
      const newFile: FileRecord = {
        ...fileData,
        id: `file-${Date.now()}`,
        created_at: new Date(),
        updated_at: new Date(),
      };
      files.push(newFile);
      return newFile;
    },
    update: (id: string, updates: Partial<FileRecord>) => {
      const index = files.findIndex((f) => f.id === id);
      if (index !== -1) {
        files[index] = { ...files[index], ...updates, updated_at: new Date() };
        return files[index];
      }
      return null;
    },
    delete: (id: string) => {
      const index = files.findIndex((f) => f.id === id);
      if (index !== -1) {
        return files.splice(index, 1)[0];
      }
      return null;
    },
  },

  sharedFiles: {
    findByToUserId: (userId: string) =>
      sharedFiles.filter((sf) => sf.to_user_id === userId),
    findByFromUserId: (userId: string) =>
      sharedFiles.filter((sf) => sf.from_user_id === userId),
    create: (shareData: Omit<SharedFile, "id">) => {
      const newShare: SharedFile = {
        ...shareData,
        id: `share-${Date.now()}`,
      };
      sharedFiles.push(newShare);
      return newShare;
    },
    delete: (id: string) => {
      const index = sharedFiles.findIndex((sf) => sf.id === id);
      if (index !== -1) {
        return sharedFiles.splice(index, 1)[0];
      }
      return null;
    },
  },

  fileActivities: {
    findByFileId: (fileId: string) =>
      fileActivities.filter((fa) => fa.file_id === fileId),
    create: (activityData: Omit<FileActivity, "id">) => {
      const newActivity: FileActivity = {
        ...activityData,
        id: `activity-${Date.now()}`,
      };
      fileActivities.push(newActivity);
      return newActivity;
    },
  },
};
