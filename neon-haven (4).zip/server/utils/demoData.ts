import fs from "fs";
import path from "path";

const DEMO_DATA_FILE = path.join(process.cwd(), "demo-data.json");

interface DemoData {
  files: any[];
  folders: any[];
}

let demoData: DemoData = {
  files: [],
  folders: [],
};

// Load demo data from file on startup
export const loadDemoData = (): DemoData => {
  try {
    if (fs.existsSync(DEMO_DATA_FILE)) {
      const data = fs.readFileSync(DEMO_DATA_FILE, "utf8");
      demoData = JSON.parse(data);
      console.log("📁 Demo data loaded from file");
    } else {
      // Initialize with some default folders
      demoData = {
        files: [],
        folders: [
          {
            id: "folder-documents",
            name: "Documents",
            type: "folder",
            modifiedAt: new Date(),
            parent_id: null,
          },
          {
            id: "folder-pictures",
            name: "Pictures",
            type: "folder",
            modifiedAt: new Date(),
            parent_id: null,
          },
        ],
      };
      saveDemoData();
      console.log("📁 Demo data initialized with defaults");
    }
  } catch (error) {
    console.error("Error loading demo data:", error);
    demoData = { files: [], folders: [] };
  }
  return demoData;
};

// Save demo data to file
export const saveDemoData = (): void => {
  try {
    fs.writeFileSync(DEMO_DATA_FILE, JSON.stringify(demoData, null, 2));
  } catch (error) {
    console.error("Error saving demo data:", error);
  }
};

// Get demo files
export const getDemoFiles = (): any[] => {
  return demoData.files;
};

// Get demo folders
export const getDemoFolders = (): any[] => {
  return demoData.folders;
};

// Add demo file
export const addDemoFile = (file: any): void => {
  demoData.files.push(file);
  saveDemoData();
};

// Add demo folder
export const addDemoFolder = (folder: any): void => {
  demoData.folders.push(folder);
  saveDemoData();
};

// Update demo file
export const updateDemoFile = (id: string, updates: any): boolean => {
  const index = demoData.files.findIndex((file) => file.id === id);
  if (index !== -1) {
    demoData.files[index] = { ...demoData.files[index], ...updates };
    saveDemoData();
    return true;
  }
  return false;
};

// Update demo folder
export const updateDemoFolder = (id: string, updates: any): boolean => {
  const index = demoData.folders.findIndex((folder) => folder.id === id);
  if (index !== -1) {
    demoData.folders[index] = { ...demoData.folders[index], ...updates };
    saveDemoData();
    return true;
  }
  return false;
};

// Delete demo file
export const deleteDemoFile = (id: string): boolean => {
  const index = demoData.files.findIndex((file) => file.id === id);
  if (index !== -1) {
    demoData.files.splice(index, 1);
    saveDemoData();
    return true;
  }
  return false;
};

// Delete demo folder
export const deleteDemoFolder = (id: string): boolean => {
  const index = demoData.folders.findIndex((folder) => folder.id === id);
  if (index !== -1) {
    demoData.folders.splice(index, 1);
    saveDemoData();
    return true;
  }
  return false;
};

// Initialize demo data on module load
loadDemoData();
