import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import { authenticateToken } from "./auth";
import { initializeDatabase } from "./db/init";
import { upload, handleUploadError } from "./middleware/upload";

// Auth routes
import {
  handleLogin,
  handleRegister,
  handleMe,
  handleLogout,
  handleGetDepartments,
} from "./routes/auth";

// File routes
import {
  handleGetFiles,
  handleGetFile,
  handleCreateFile,
  handleFileUpload,
  handleUpdateFile,
  handleDeleteFile,
  handleDownloadFile,
  handleShareFile,
  handleGetSharedFiles,
} from "./routes/files-simple";

// Folder routes
import {
  handleGetFolders,
  handleGetFolder,
  handleCreateFolder,
  handleUpdateFolder,
  handleDeleteFolder,
  handleGetFolderTree,
} from "./routes/folders-simple";

// User routes
import {
  handleSearchUsers,
  handleGetDashboardStats,
  handleGetRecentFiles,
} from "./routes/users-simple";

// Debug routes
import {
  handleViewUsers,
  handleViewDepartments,
  handleViewAllTables,
} from "./routes/debug";

export function createServer() {
  const app = express();

  // Initialize database (async, don't block server start)
  initializeDatabase().catch((error) => {
    console.error("Failed to initialize database:", error);
  });

  // Middleware
  app.use(cors());
  app.use(express.json({ limit: "10mb" }));
  app.use(express.urlencoded({ extended: true, limit: "10mb" }));

  // Serve uploaded files
  app.use("/uploads", express.static("uploads"));

  // Health check
  app.get("/api/ping", (_req, res) => {
    res.json({ message: "FileVault API is running!" });
  });

  // Public routes (no authentication required)
  app.post("/api/auth/login", handleLogin);
  app.post("/api/auth/register", handleRegister);
  app.get("/api/auth/departments", handleGetDepartments);

  // Temporary test login (remove in production)
  app.post("/api/auth/test-login", async (req, res) => {
    try {
      const { email } = req.body;
      const user = await require("./db/connection").User.findOne({
        where: { email },
        include: [{ association: "department" }],
      });

      if (user) {
        const token = require("./auth").jwtUtils.sign({
          userId: user.id,
          email: user.email,
          role: user.role,
        });

        res.json({
          token,
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
            department: user.department?.name || "Unknown",
          },
          message: "Test login successful",
        });
      } else {
        res.status(404).json({ error: "User not found" });
      }
    } catch (error) {
      console.error("Test login error:", error);
      res.status(500).json({ error: "Test login failed" });
    }
  });

  // Demo route (keep for compatibility)
  app.get("/api/demo", handleDemo);

  // Debug routes (temporary for database inspection)
  app.get("/api/debug/users", handleViewUsers);
  app.get("/api/debug/departments", handleViewDepartments);
  app.get("/api/debug/all", handleViewAllTables);

  // Auth routes (protected) - these need to be defined before the general middleware
  app.get("/api/auth/me", authenticateToken, handleMe);
  app.post("/api/auth/logout", authenticateToken, handleLogout);

  // User routes (protected)
  app.get("/api/users/search", authenticateToken, handleSearchUsers);
  app.get("/api/dashboard/stats", authenticateToken, handleGetDashboardStats);
  app.get("/api/files/recent", authenticateToken, handleGetRecentFiles);

  // Folder routes (protected)
  app.get("/api/folders", authenticateToken, handleGetFolders);
  app.get("/api/folders/tree", authenticateToken, handleGetFolderTree);
  app.get("/api/folders/:id", authenticateToken, handleGetFolder);
  app.post("/api/folders", authenticateToken, handleCreateFolder);
  app.put("/api/folders/:id", authenticateToken, handleUpdateFolder);
  app.delete("/api/folders/:id", authenticateToken, handleDeleteFolder);

  // File routes (protected)
  app.get("/api/files", authenticateToken, handleGetFiles);
  app.get("/api/files/shared", authenticateToken, handleGetSharedFiles);
  app.get("/api/files/:id", authenticateToken, handleGetFile);
  app.post("/api/files", authenticateToken, handleCreateFile);
  app.post(
    "/api/files/upload",
    authenticateToken,
    upload.array("files", 10),
    handleFileUpload,
  );
  app.put("/api/files/:id", authenticateToken, handleUpdateFile);
  app.delete("/api/files/:id", authenticateToken, handleDeleteFile);
  app.get("/api/files/:id/download", authenticateToken, handleDownloadFile);
  app.post("/api/files/:id/share", authenticateToken, handleShareFile);

  // Upload error handler
  app.use(handleUploadError);

  return app;
}
