#!/usr/bin/env node

import { execSync } from "child_process";
import fs from "fs";
import path from "path";

console.log("🚀 Setting up FileVault...");

// Create necessary directories
const dirs = ["uploads", "database"];
dirs.forEach((dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    console.log(`✅ Created ${dir} directory`);
  }
});

// Check if database exists
const dbPath = "./filevault.db";
if (fs.existsSync(dbPath)) {
  console.log("📊 Database already exists");
} else {
  console.log("🗃️ Database will be created on first run");
}

console.log("✅ Setup complete!");
console.log("");
console.log("To start the application:");
console.log("1. npm run dev");
console.log("2. Open http://localhost:8080");
console.log("3. Login with: john@example.com / password123");
console.log("");
console.log("🎉 Happy file managing!");
