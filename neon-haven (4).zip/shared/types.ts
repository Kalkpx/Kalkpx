// Shared types for FileVault application

export interface FileItem {
  id: string;
  name: string;
  type: "file" | "folder";
  size?: number;
  modifiedAt: Date;
  sharedWith?: number;
}

export interface SharedFileItem extends FileItem {
  sharedBy?: string;
  sharedWithUsers?: string[];
  sharedAt?: Date;
}

export interface User {
  id: string;
  name: string;
  email: string;
  department: string;
  role: "admin" | "user";
}

export interface Department {
  id: string;
  name: string;
}

export interface FolderItem extends FileItem {
  type: "folder";
  parent_id?: string | null;
  path: string;
  full_path: string;
  fileCount?: number;
  subfolderCount?: number;
}

export interface FileRecord extends FileItem {
  type: "file";
  folder_id?: string | null;
  user_id: string;
  path: string;
}

export interface ShareData {
  id: string;
  file_id: string;
  from_user_id: string;
  to_user_id: string;
  shared_at: Date;
}

export interface FileActivity {
  id: string;
  file_id: string;
  user_id: string;
  action: "uploaded" | "shared" | "renamed" | "deleted" | "downloaded";
  created_at: Date;
  fileName?: string;
}

export interface DashboardStats {
  totalFiles: number;
  totalFolders: number;
  totalStorage: number;
  recentFiles: number;
  sharedByMeCount: number;
  sharedWithMeCount: number;
  recentActivities: FileActivity[];
  storageLimit: number;
}
