import React, { useState, useEffect } from "react";
import { toast } from "sonner";
import { Layout } from "@/components/layout/Layout";
import { FileUpload } from "@/components/file-manager/FileUpload";
import { FileGrid } from "@/components/file-manager/FileGrid";
import { useFileManager } from "@/hooks/useFileManager";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  FiSearch,
  FiFilter,
  FiPlus,
  FiUpload,
  FiGrid,
  FiList,
  FiFolderPlus,
  FiHome,
  FiChevronRight,
} from "react-icons/fi";

interface FileItem {
  id: string;
  name: string;
  type: "file" | "folder";
  size?: number;
  modifiedAt: Date;
  sharedWith?: number;
}

export const Dashboard: React.FC = () => {
  const {
    items,
    isLoading,
    currentFolder,
    loadItems,
    uploadFiles,
    createFolder,
    renameItem,
    deleteItem,
    downloadFile,
    shareFile,
  } = useFileManager();

  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [currentPath] = useState(["Home"]);

  // Load initial data
  useEffect(() => {
    loadItems();
  }, [loadItems]);

  const filteredItems = items
    .filter((item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    .sort((a, b) => {
      switch (sortBy) {
        case "name":
          return a.name.localeCompare(b.name);
        case "date":
          return b.modifiedAt.getTime() - a.modifiedAt.getTime();
        case "size":
          return (b.size || 0) - (a.size || 0);
        case "type":
          return a.type.localeCompare(b.type);
        default:
          return 0;
      }
    });

  const handleUpload = async (files: File[]) => {
    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          setIsUploading(false);
          setIsUploadDialogOpen(false);
          return 100;
        }
        return prev + 10;
      });
    }, 200);

    await uploadFiles(files, currentFolder);
  };

  const handleItemClick = (item: FileItem) => {
    if (item.type === "folder") {
      loadItems(item.id);
    } else {
      toast.info(`Opening file: ${item.name}`);
    }
  };

  const handleRename = (item: FileItem) => {
    const newName = prompt("Enter new name:", item.name);
    if (newName && newName !== item.name) {
      renameItem(item, newName);
    }
  };

  const handleDelete = (item: FileItem) => {
    if (confirm(`Are you sure you want to delete "${item.name}"?`)) {
      deleteItem(item);
    }
  };

  const handleDownload = (item: FileItem) => {
    downloadFile(item);
  };

  const handleShare = (item: FileItem) => {
    // For now, just show a message. In a real app, this would open a share dialog
    toast.info(`Share dialog for: ${item.name}`);
  };

  const handleCreateFolder = () => {
    const folderName = prompt("Enter folder name:");
    if (folderName) {
      createFolder(folderName, currentFolder);
    }
  };

  // Calculate real stats from all items (not just current folder)
  const [allItems, setAllItems] = React.useState<FileItem[]>([]);

  // Load all items for stats calculation
  React.useEffect(() => {
    const loadAllItems = async () => {
      try {
        const [filesResponse, foldersResponse] = await Promise.all([
          axios.get("/api/files", {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("authToken")}`,
            },
          }),
          axios.get("/api/folders", {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("authToken")}`,
            },
          }),
        ]);

        const allFiles = filesResponse.data.files.map((file: any) => ({
          ...file,
          type: "file" as const,
          modifiedAt: new Date(file.modifiedAt),
        }));

        const allFolders = foldersResponse.data.folders.map((folder: any) => ({
          ...folder,
          type: "folder" as const,
          modifiedAt: new Date(folder.modifiedAt),
        }));

        setAllItems([...allFolders, ...allFiles]);
      } catch (error) {
        console.error("Error loading all items for stats:", error);
      }
    };

    loadAllItems();
  }, [items]); // Recalculate when items change

  const stats = {
    totalFiles: allItems.filter((item) => item.type === "file").length,
    totalFolders: allItems.filter((item) => item.type === "folder").length,
    totalSize: allItems
      .filter((item) => item.type === "file")
      .reduce((acc, item) => acc + (item.size || 0), 0),
    recentFiles: allItems
      .filter((item) => item.type === "file")
      .filter(
        (item) =>
          new Date().getTime() - item.modifiedAt.getTime() <
          7 * 24 * 60 * 60 * 1000,
      ).length,
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header with Breadcrumb */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-1">
              {currentPath.map((path, index) => (
                <React.Fragment key={index}>
                  <FiHome className="h-4 w-4" />
                  <span>{path}</span>
                  {index < currentPath.length - 1 && (
                    <FiChevronRight className="h-4 w-4" />
                  )}
                </React.Fragment>
              ))}
            </div>
            <h1 className="text-3xl font-bold">File Manager</h1>
          </div>
          <div className="flex items-center space-x-3">
            <Button onClick={handleCreateFolder} variant="outline">
              <FiFolderPlus className="h-4 w-4 mr-2" />
              New Folder
            </Button>
            <Dialog
              open={isUploadDialogOpen}
              onOpenChange={setIsUploadDialogOpen}
            >
              <DialogTrigger asChild>
                <Button>
                  <FiUpload className="h-4 w-4 mr-2" />
                  Upload Files
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Upload Files</DialogTitle>
                </DialogHeader>
                <FileUpload
                  onUpload={handleUpload}
                  isUploading={isUploading}
                  uploadProgress={uploadProgress}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-lg border bg-card">
            <h3 className="text-sm font-medium text-muted-foreground">
              Total Files
            </h3>
            <p className="text-2xl font-bold">{stats.totalFiles}</p>
          </div>
          <div className="p-4 rounded-lg border bg-card">
            <h3 className="text-sm font-medium text-muted-foreground">
              Total Folders
            </h3>
            <p className="text-2xl font-bold">{stats.totalFolders}</p>
          </div>
          <div className="p-4 rounded-lg border bg-card">
            <h3 className="text-sm font-medium text-muted-foreground">
              Storage Used
            </h3>
            <p className="text-2xl font-bold">
              {(stats.totalSize / (1024 * 1024)).toFixed(1)} MB
            </p>
          </div>
          <div className="p-4 rounded-lg border bg-card">
            <h3 className="text-sm font-medium text-muted-foreground">
              Recent Files
            </h3>
            <p className="text-2xl font-bold">{stats.recentFiles}</p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search files and folders..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Sort by Name</SelectItem>
                <SelectItem value="date">Sort by Date</SelectItem>
                <SelectItem value="size">Sort by Size</SelectItem>
                <SelectItem value="type">Sort by Type</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant={viewMode === "grid" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("grid")}
            >
              <FiGrid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("list")}
            >
              <FiList className="h-4 w-4" />
            </Button>
            <Badge variant="secondary" className="ml-4">
              {filteredItems.length} items
            </Badge>
          </div>
        </div>

        {/* File Grid */}
        <FileGrid
          items={filteredItems}
          onItemClick={handleItemClick}
          onRename={handleRename}
          onDelete={handleDelete}
          onDownload={handleDownload}
          onShare={handleShare}
          isLoading={isLoading}
        />
      </div>
    </Layout>
  );
};

export default Dashboard;
