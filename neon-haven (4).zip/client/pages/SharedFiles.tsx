import React, { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { FileGrid } from "@/components/file-manager/FileGrid";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { FiSearch, FiShare2, FiUsers } from "react-icons/fi";
import { toast } from "sonner";

interface SharedFileItem {
  id: string;
  name: string;
  type: "file" | "folder";
  size?: number;
  modifiedAt: Date;
  sharedWith?: number; // Keep consistent with FileItem
  sharedBy?: string;
  sharedWithUsers?: string[]; // Rename to avoid conflict
}

export const SharedFiles: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const sharedWithMe: SharedFileItem[] = [
    {
      id: "s1",
      name: "Q4 Financial Report.pdf",
      type: "file",
      size: 3200000,
      modifiedAt: new Date("2024-01-14"),
      sharedBy: "John Doe",
    },
    {
      id: "s2",
      name: "Marketing Materials",
      type: "folder",
      modifiedAt: new Date("2024-01-13"),
      sharedBy: "Jane Smith",
    },
    {
      id: "s3",
      name: "Product Roadmap.pptx",
      type: "file",
      size: 5600000,
      modifiedAt: new Date("2024-01-12"),
      sharedBy: "Mike Johnson",
    },
  ];

  const sharedByMe: SharedFileItem[] = [
    {
      id: "sb1",
      name: "Team Guidelines.docx",
      type: "file",
      size: 890000,
      modifiedAt: new Date("2024-01-11"),
      sharedWith: 2,
      sharedWithUsers: ["Alice Brown", "Bob Wilson"],
    },
    {
      id: "sb2",
      name: "Project Resources",
      type: "folder",
      modifiedAt: new Date("2024-01-10"),
      sharedWith: 2,
      sharedWithUsers: ["Dev Team", "QA Team"],
    },
  ];

  const handleItemClick = (item: SharedFileItem) => {
    toast.info(`Opening: ${item.name}`);
  };

  const handleRename = (item: SharedFileItem) => {
    toast.info(`Rename functionality for: ${item.name}`);
  };

  const handleDelete = (item: SharedFileItem) => {
    toast.info(`Delete functionality for: ${item.name}`);
  };

  const handleDownload = (item: SharedFileItem) => {
    toast.info(`Downloading: ${item.name}`);
  };

  const handleShare = (item: SharedFileItem) => {
    toast.info(`Share dialog for: ${item.name}`);
  };

  const filterItems = (items: SharedFileItem[]) =>
    items.filter((item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()),
    );

  return (
    <Layout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Shared Files</h1>
            <p className="text-muted-foreground">
              Files shared with you and by you
            </p>
          </div>
          <Button>
            <FiShare2 className="h-4 w-4 mr-2" />
            Share File
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-lg border bg-card">
            <h3 className="text-sm font-medium text-muted-foreground">
              Shared with Me
            </h3>
            <p className="text-2xl font-bold">{sharedWithMe.length}</p>
          </div>
          <div className="p-4 rounded-lg border bg-card">
            <h3 className="text-sm font-medium text-muted-foreground">
              Shared by Me
            </h3>
            <p className="text-2xl font-bold">{sharedByMe.length}</p>
          </div>
          <div className="p-4 rounded-lg border bg-card">
            <h3 className="text-sm font-medium text-muted-foreground">
              Total Recipients
            </h3>
            <p className="text-2xl font-bold">
              {sharedByMe.reduce(
                (acc, item) => acc + (item.sharedWithUsers?.length || 0),
                0,
              )}
            </p>
          </div>
        </div>

        {/* Search */}
        <div className="flex items-center space-x-4">
          <div className="relative flex-1 max-w-md">
            <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search shared files..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="shared-with-me" className="space-y-6">
          <TabsList>
            <TabsTrigger value="shared-with-me" className="flex items-center">
              <FiUsers className="h-4 w-4 mr-2" />
              Shared with Me
              <Badge variant="secondary" className="ml-2">
                {sharedWithMe.length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="shared-by-me" className="flex items-center">
              <FiShare2 className="h-4 w-4 mr-2" />
              Shared by Me
              <Badge variant="secondary" className="ml-2">
                {sharedByMe.length}
              </Badge>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="shared-with-me" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Files Shared with You</h3>
              <Badge variant="outline">
                {filterItems(sharedWithMe).length} items
              </Badge>
            </div>
            <FileGrid
              items={filterItems(sharedWithMe)}
              onItemClick={handleItemClick}
              onRename={handleRename}
              onDelete={handleDelete}
              onDownload={handleDownload}
              onShare={handleShare}
            />
          </TabsContent>

          <TabsContent value="shared-by-me" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Files You've Shared</h3>
              <Badge variant="outline">
                {filterItems(sharedByMe).length} items
              </Badge>
            </div>
            <FileGrid
              items={filterItems(sharedByMe)}
              onItemClick={handleItemClick}
              onRename={handleRename}
              onDelete={handleDelete}
              onDownload={handleDownload}
              onShare={handleShare}
            />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default SharedFiles;
