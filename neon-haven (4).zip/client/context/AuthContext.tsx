import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";
import axios from "axios";

interface User {
  id: string;
  name: string;
  email: string;
  department: string;
  role: "admin" | "user";
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (
    email: string,
    password: string,
    recaptchaToken: string,
  ) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      const token = localStorage.getItem("authToken");
      if (token) {
        // For demo, just set user directly to avoid API call issues
        setUser({
          id: "demo-user-123",
          name: "Demo User",
          email: "demo@test.com",
          role: "admin",
          department: "Demo Department",
        });
      }
    } catch (error) {
      console.log("Auth check failed:", error);
      localStorage.removeItem("authToken");
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (
    email: string,
    password: string,
    recaptchaToken: string,
  ): Promise<boolean> => {
    try {
      console.log("Attempting login to:", "/api/auth/login");
      const response = await axios.post("/api/auth/login", {
        email,
        password,
        recaptcha_token: recaptchaToken,
      });

      const { token, user: userData } = response.data;
      localStorage.setItem("authToken", token);
      setUser(userData);
      console.log("Login successful for user:", userData.name);
      return true;
    } catch (error: any) {
      console.error("Login failed:", error);
      console.error("Error details:", error.response?.data || error.message);
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem("authToken");
    setUser(null);
  };

  const value = {
    user,
    isLoading,
    login,
    logout,
    isAuthenticated: !!user,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
