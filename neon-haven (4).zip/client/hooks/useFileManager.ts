import { useState, useCallback } from "react";
import axios from "axios";
import { toast } from "sonner";
import { useNotifications } from "@/context/NotificationContext";

interface FileItem {
  id: string;
  name: string;
  type: "file" | "folder";
  size?: number;
  modifiedAt: Date;
  sharedWith?: number;
}

export const useFileManager = () => {
  const [items, setItems] = useState<FileItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentFolder, setCurrentFolder] = useState<string | null>(null);
  const { addNotification } = useNotifications();

  // Get auth token
  const getAuthHeader = () => {
    const token = localStorage.getItem("authToken");
    return token ? { Authorization: `Bearer ${token}` } : {};
  };

  // Load files and folders
  const loadItems = useCallback(async (folderId?: string | null) => {
    setIsLoading(true);
    try {
      const [filesResponse, foldersResponse] = await Promise.all([
        axios.get("/api/files", {
          params: { folder_id: folderId },
          headers: getAuthHeader(),
        }),
        axios.get("/api/folders", {
          params: { parent_id: folderId },
          headers: getAuthHeader(),
        }),
      ]);

      const files = filesResponse.data.files.map((file: any) => ({
        ...file,
        type: "file" as const,
        modifiedAt: new Date(file.updated_at),
        sharedWith: file.sharedWith || 0,
      }));

      const folders = foldersResponse.data.folders.map((folder: any) => ({
        ...folder,
        type: "folder" as const,
        modifiedAt: new Date(folder.updated_at),
        size: undefined,
      }));

      setItems([...folders, ...files]);
      setCurrentFolder(folderId || null);
    } catch (error) {
      console.error("Error loading items:", error);
      toast.error("Failed to load files and folders");
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Upload files
  const uploadFiles = useCallback(
    async (files: File[], folderId?: string | null) => {
      try {
        const formData = new FormData();

        // Add files to form data
        files.forEach((file) => {
          formData.append("files", file);
        });

        // Add folder_id if provided
        if (folderId) {
          formData.append("folder_id", folderId);
        }

        const response = await axios.post("/api/files/upload", formData, {
          headers: {
            ...getAuthHeader(),
            "Content-Type": "multipart/form-data",
          },
        });

        const successMessage =
          response.data.message ||
          `Successfully uploaded ${files.length} file(s)`;

        toast.success(successMessage);

        // Add notification for each uploaded file
        files.forEach((file) => {
          addNotification(
            `File '${file.name}' uploaded successfully`,
            "upload",
          );
        });

        loadItems(currentFolder);
      } catch (error: any) {
        console.error("Error uploading files:", error);
        const message = error.response?.data?.error || "Failed to upload files";
        toast.error(message);
      }
    },
    [currentFolder, loadItems],
  );

  // Create folder
  const createFolder = useCallback(
    async (name: string, parentId?: string | null) => {
      try {
        console.log("Creating folder:", { name, parent_id: parentId });
        const response = await axios.post(
          "/api/folders",
          {
            name,
            parent_id: parentId,
          },
          {
            headers: getAuthHeader(),
          },
        );

        console.log("Folder created successfully:", response.data);
        toast.success(`Folder "${name}" created successfully`);
        addNotification(`Folder '${name}' created successfully`, "folder");
        loadItems(currentFolder);
      } catch (error: any) {
        console.error("Error creating folder:", error);
        console.error("Error response:", error.response?.data);
        console.error("Error status:", error.response?.status);
        const message =
          error.response?.data?.error || "Failed to create folder";
        toast.error(message);
      }
    },
    [currentFolder, loadItems],
  );

  // Rename item
  const renameItem = useCallback(
    async (item: FileItem, newName: string) => {
      try {
        const endpoint =
          item.type === "folder"
            ? `/api/folders/${item.id}`
            : `/api/files/${item.id}`;

        await axios.put(
          endpoint,
          { name: newName },
          {
            headers: getAuthHeader(),
          },
        );

        toast.success(`"${item.name}" renamed to "${newName}"`);
        loadItems(currentFolder);
      } catch (error) {
        console.error("Error renaming item:", error);
        toast.error("Failed to rename item");
      }
    },
    [currentFolder, loadItems],
  );

  // Delete item
  const deleteItem = useCallback(
    async (item: FileItem) => {
      try {
        const endpoint =
          item.type === "folder"
            ? `/api/folders/${item.id}`
            : `/api/files/${item.id}`;

        await axios.delete(endpoint, {
          headers: getAuthHeader(),
        });

        toast.success(`"${item.name}" deleted successfully`);
        loadItems(currentFolder);
      } catch (error: any) {
        console.error("Error deleting item:", error);
        const message = error.response?.data?.error || "Failed to delete item";
        toast.error(message);
      }
    },
    [currentFolder, loadItems],
  );

  // Download file
  const downloadFile = useCallback(async (item: FileItem) => {
    try {
      const response = await axios.get(`/api/files/${item.id}/download`, {
        headers: getAuthHeader(),
      });

      toast.success(`Download initiated for "${item.name}"`);
    } catch (error) {
      console.error("Error downloading file:", error);
      toast.error("Failed to download file");
    }
  }, []);

  // Share file
  const shareFile = useCallback(async (item: FileItem, userId: string) => {
    try {
      await axios.post(
        `/api/files/${item.id}/share`,
        { to_user_id: userId },
        {
          headers: getAuthHeader(),
        },
      );

      toast.success(`"${item.name}" shared successfully`);
    } catch (error: any) {
      console.error("Error sharing file:", error);
      const message = error.response?.data?.error || "Failed to share file";
      toast.error(message);
    }
  }, []);

  return {
    items,
    isLoading,
    currentFolder,
    loadItems,
    uploadFiles,
    createFolder,
    renameItem,
    deleteItem,
    downloadFile,
    shareFile,
  };
};
