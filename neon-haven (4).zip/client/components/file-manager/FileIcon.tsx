import React from "react";
import {
  FiFile,
  FiFileText,
  FiImage,
  FiFolder,
  FiArchive,
} from "react-icons/fi";

interface FileIconProps {
  type:
    | "folder"
    | "pdf"
    | "excel"
    | "word"
    | "powerpoint"
    | "autocad"
    | "other";
  className?: string;
}

export const FileIcon: React.FC<FileIconProps> = ({
  type,
  className = "h-8 w-8",
}) => {
  switch (type) {
    case "folder":
      return <FiFolder className={`${className} text-primary`} />;
    case "pdf":
      return (
        <div className={`${className} relative`}>
          <FiFileText className="h-full w-full text-red-500" />
        </div>
      );
    case "excel":
      return (
        <div className={`${className} relative`}>
          <FiFileText className="h-full w-full text-green-600" />
        </div>
      );
    case "word":
      return (
        <div className={`${className} relative`}>
          <FiFileText className="h-full w-full text-blue-600" />
        </div>
      );
    case "powerpoint":
      return (
        <div className={`${className} relative`}>
          <FiFileText className="h-full w-full text-orange-500" />
        </div>
      );
    case "autocad":
      return (
        <div className={`${className} relative`}>
          <FiFileText className="h-full w-full text-yellow-600" />
        </div>
      );
    default:
      return <FiFile className={`${className} text-muted-foreground`} />;
  }
};

export const getFileType = (fileName: string): FileIconProps["type"] => {
  const extension = fileName.split(".").pop()?.toLowerCase();

  switch (extension) {
    case "pdf":
      return "pdf";
    case "xls":
    case "xlsx":
      return "excel";
    case "doc":
    case "docx":
      return "word";
    case "ppt":
    case "pptx":
      return "powerpoint";
    case "dwg":
    case "dxf":
      return "autocad";
    default:
      return "other";
  }
};
