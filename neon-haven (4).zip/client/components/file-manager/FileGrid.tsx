import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { FileIcon, getFileType } from "./FileIcon";
import {
  FiMoreHorizontal,
  FiDownload,
  FiShare2,
  FiEdit2,
  FiTrash2,
  FiFolder,
} from "react-icons/fi";

interface FileItem {
  id: string;
  name: string;
  type: "file" | "folder";
  size?: number;
  modifiedAt: Date;
  sharedWith?: number;
}

interface FileGridProps {
  items: FileItem[];
  onItemClick: (item: FileItem) => void;
  onRename: (item: FileItem) => void;
  onDelete: (item: FileItem) => void;
  onDownload: (item: FileItem) => void;
  onShare: (item: FileItem) => void;
  isLoading?: boolean;
}

export const FileGrid: React.FC<FileGridProps> = ({
  items,
  onItemClick,
  onRename,
  onDelete,
  onDownload,
  onShare,
  isLoading = false,
}) => {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const formatDate = (date: Date): string => {
    try {
      // Handle cases where date might be a string or invalid
      const validDate = date instanceof Date ? date : new Date(date);

      // Check if the date is valid
      if (isNaN(validDate.getTime())) {
        return "Unknown";
      }

      return new Intl.DateTimeFormat("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      }).format(validDate);
    } catch (error) {
      return "Unknown";
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {Array.from({ length: 12 }).map((_, index) => (
          <div
            key={index}
            className="p-4 border rounded-lg bg-card animate-pulse"
          >
            <div className="h-12 bg-muted rounded mb-3"></div>
            <div className="h-4 bg-muted rounded mb-2"></div>
            <div className="h-3 bg-muted rounded w-2/3"></div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
      <AnimatePresence>
        {items.map((item) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className="group relative"
          >
            <div
              className="p-4 border rounded-lg bg-card hover:bg-accent cursor-pointer transition-colors"
              onMouseEnter={() => setHoveredItem(item.id)}
              onMouseLeave={() => setHoveredItem(null)}
              onDoubleClick={() => onItemClick(item)}
            >
              {/* File/Folder Icon */}
              <div className="flex items-center justify-center mb-3">
                {item.type === "folder" ? (
                  <FileIcon type="folder" className="h-12 w-12" />
                ) : (
                  <FileIcon
                    type={getFileType(item.name)}
                    className="h-12 w-12"
                  />
                )}
              </div>

              {/* File Name */}
              <h3
                className="text-sm font-medium truncate mb-1"
                title={item.name}
              >
                {item.name}
              </h3>

              {/* File Details */}
              <div className="text-xs text-muted-foreground space-y-1">
                {item.type === "file" && item.size && (
                  <p>{formatFileSize(item.size)}</p>
                )}
                <p>{formatDate(item.modifiedAt)}</p>
                {item.sharedWith && item.sharedWith > 0 && (
                  <Badge variant="secondary" className="text-xs">
                    Shared with {item.sharedWith}
                  </Badge>
                )}
              </div>

              {/* Actions Menu */}
              <div
                className={`absolute top-2 right-2 transition-opacity ${
                  hoveredItem === item.id ? "opacity-100" : "opacity-0"
                }`}
              >
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0 bg-background/80 hover:bg-background"
                    >
                      <FiMoreHorizontal className="h-3 w-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onItemClick(item)}>
                      <FiFolder className="mr-2 h-4 w-4" />
                      Open
                    </DropdownMenuItem>
                    {item.type === "file" && (
                      <DropdownMenuItem onClick={() => onDownload(item)}>
                        <FiDownload className="mr-2 h-4 w-4" />
                        Download
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={() => onShare(item)}>
                      <FiShare2 className="mr-2 h-4 w-4" />
                      Share
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => onRename(item)}>
                      <FiEdit2 className="mr-2 h-4 w-4" />
                      Rename
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => onDelete(item)}
                      className="text-destructive"
                    >
                      <FiTrash2 className="mr-2 h-4 w-4" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};
