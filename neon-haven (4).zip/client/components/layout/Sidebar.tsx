import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  FiHome,
  FiFolder,
  FiShare2,
  FiPlus,
  FiChevronRight,
  FiChevronDown,
  FiHardDrive,
  FiUsers,
  FiClock,
} from "react-icons/fi";

interface FolderItem {
  id: string;
  name: string;
  children?: FolderItem[];
  fileCount?: number;
}

export const Sidebar: React.FC = () => {
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(
    new Set(["1"]),
  );
  const [recentFilesCount, setRecentFilesCount] = useState(0);

  // Calculate recent files count
  useEffect(() => {
    const calculateRecentFiles = async () => {
      try {
        const response = await fetch("/api/files", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("authToken")}`,
          },
        });
        const data = await response.json();

        const recentCount = data.files.filter((file: any) => {
          const fileDate = new Date(file.modifiedAt);
          const daysDiff =
            (Date.now() - fileDate.getTime()) / (1000 * 60 * 60 * 24);
          return daysDiff <= 7; // Files from last 7 days
        }).length;

        setRecentFilesCount(recentCount);
      } catch (error) {
        console.error("Error calculating recent files:", error);
        setRecentFilesCount(0);
      }
    };

    calculateRecentFiles();
  }, []);
  const [folders] = useState<FolderItem[]>([
    {
      id: "1",
      name: "Documents",
      fileCount: 15,
      children: [
        { id: "1-1", name: "Projects", fileCount: 8 },
        { id: "1-2", name: "Reports", fileCount: 7 },
      ],
    },
    {
      id: "2",
      name: "Images",
      fileCount: 23,
    },
    {
      id: "3",
      name: "Archives",
      fileCount: 5,
    },
  ]);

  const toggleFolder = (folderId: string) => {
    const newExpanded = new Set(expandedFolders);
    if (newExpanded.has(folderId)) {
      newExpanded.delete(folderId);
    } else {
      newExpanded.add(folderId);
    }
    setExpandedFolders(newExpanded);
  };

  const renderFolder = (folder: FolderItem, level: number = 0) => {
    const isExpanded = expandedFolders.has(folder.id);
    const hasChildren = folder.children && folder.children.length > 0;

    return (
      <div key={folder.id}>
        <div
          className={`flex items-center space-x-2 rounded-lg px-3 py-2 text-sm hover:bg-accent cursor-pointer ${
            level > 0 ? "ml-4" : ""
          }`}
          onClick={() => hasChildren && toggleFolder(folder.id)}
        >
          {hasChildren ? (
            isExpanded ? (
              <FiChevronDown className="h-4 w-4 text-muted-foreground" />
            ) : (
              <FiChevronRight className="h-4 w-4 text-muted-foreground" />
            )
          ) : (
            <div className="w-4 h-4" />
          )}
          <FiFolder className="h-4 w-4 text-primary" />
          <span className="flex-1">{folder.name}</span>
          {folder.fileCount && (
            <Badge variant="secondary" className="text-xs">
              {folder.fileCount}
            </Badge>
          )}
        </div>
        {hasChildren &&
          isExpanded &&
          folder.children?.map((child) => renderFolder(child, level + 1))}
      </div>
    );
  };

  return (
    <div className="w-64 border-r bg-sidebar h-full flex flex-col">
      <div className="p-4">
        {/* Dashboard Section */}
        <div className="space-y-2">
          <h3 className="text-sm font-semibold text-sidebar-foreground px-3">
            Dashboard
          </h3>
          <nav className="space-y-1">
            <NavLink
              to="/"
              className={({ isActive }) =>
                `flex items-center space-x-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                }`
              }
            >
              <FiHome className="h-4 w-4" />
              <span>Overview</span>
            </NavLink>
            <NavLink
              to="/recent"
              className={({ isActive }) =>
                `flex items-center space-x-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                }`
              }
            >
              <FiClock className="h-4 w-4" />
              <span>Recent Files</span>
              <Badge variant="secondary" className="ml-auto text-xs">
                {recentFilesCount}
              </Badge>
            </NavLink>
          </nav>
        </div>

        {/* Storage Info */}
        <div className="mt-6 p-3 rounded-lg bg-sidebar-accent">
          <div className="flex items-center space-x-2 mb-2">
            <FiHardDrive className="h-4 w-4" />
            <span className="text-sm font-medium">Storage</span>
          </div>
          <Progress value={68} className="h-2 mb-2" />
          <p className="text-xs text-muted-foreground">6.8 GB used of 10 GB</p>
        </div>
      </div>

      <ScrollArea className="flex-1 px-4">
        {/* Folders Section */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-sidebar-foreground px-3">
              Folders
            </h3>
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
              <FiPlus className="h-3 w-3" />
            </Button>
          </div>
          <div className="space-y-1">
            {folders.map((folder) => renderFolder(folder))}
          </div>
        </div>

        {/* Shared Files Section */}
        <div className="mt-6 space-y-2">
          <h3 className="text-sm font-semibold text-sidebar-foreground px-3">
            Shared
          </h3>
          <nav className="space-y-1">
            <NavLink
              to="/shared"
              className={({ isActive }) =>
                `flex items-center space-x-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                }`
              }
            >
              <FiShare2 className="h-4 w-4" />
              <span>Shared with me</span>
              <Badge variant="secondary" className="ml-auto text-xs">
                3
              </Badge>
            </NavLink>
            <div className="flex items-center space-x-3 rounded-lg px-3 py-2 text-sm text-sidebar-foreground">
              <FiUsers className="h-4 w-4" />
              <span>Shared by me</span>
              <Badge variant="secondary" className="ml-auto text-xs">
                7
              </Badge>
            </div>
          </nav>
        </div>
      </ScrollArea>

      {/* Bottom Alert/Info */}
      <div className="p-4 border-t">
        <div className="p-3 rounded-lg bg-primary/10 border border-primary/20">
          <p className="text-xs text-primary font-medium mb-1">
            New Feature Available!
          </p>
          <p className="text-xs text-muted-foreground">
            Try our new file sharing with external users.
          </p>
        </div>
      </div>
    </div>
  );
};
