import React from "react";

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center space-x-4">
            <span>© {currentYear} FileVault Technologies Inc.</span>
            <span>•</span>
            <span>All rights reserved</span>
          </div>
          <div className="flex items-center space-x-4">
            <span>Version 2.1.0</span>
            <span>•</span>
            <span>Enterprise Edition</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
